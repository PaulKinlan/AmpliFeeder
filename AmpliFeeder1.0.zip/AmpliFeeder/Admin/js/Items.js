﻿/// <reference path="jquery.intellisense.js"/>
/// <reference path="Pager.js"/>

var PageSize = 10;
var PageNumber = 1;
var PageCount = 0;

$(document).ready(function() { LoadAndRenderItems();  });

LoadAndRenderItems = function() {

    var parameterObject = '{"PageSize":"' + PageSize + '", "PageNumber":"' + PageNumber + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/GetItemsForModerationPackage", RenderItems, AjaxFailure);
    
}

RenderItems = function(data) {

    var items = eval('(' + data.d + ')');

    PageCount = items.PageCount;

    $("#TemplateItemsHolder").empty();

    $.each(items.FeedItems, function(i, item) { RenderItem(item); });

    $("#pager").pager({ pagenumber: PageNumber, pagecount: PageCount, buttonClickCallback: PagerClick });

    $(".contentcell .row:even").addClass("evenrow");

    RenderButtonRollovers();

    $(".expander").hide();
}

PagerClick = function(pageclickednumber) {

    $("#TemplateItemsHolder").empty();
    $("#TemplateItemsHolder").append('<img src="../Assets/img/activity2.gif" />');
    PageNumber = pageclickednumber;
    LoadAndRenderItems();
}

RenderItem = function(item) {

    $row = $('<div class="row ' + item.Id + '"></div>');

    $row.append($('<div class="comment"><div class="itemheader"><div class="itemicon"><img alt="' + item.SourceTitle + '" src="../Assets/img/icons/24/' + item.SourceTypeName + '.png" /></div><div class="itemtitle">' + item.Title + '</div><div class="itemdate">' + item.Date + '</div></div><div style="clear:both;float:none;"></div><div class="expander"><div class="admindetail"><span class="adminlabel">Link:</span><a href="' + item.SourceLink + '">' + item.SourceLink + '</a></div><div class="admindetail"><span class="adminlabel">Data:</span>' + item.Data + '</div><div class="admindetail"><span class="adminlabel">Description:</span>' + item.Description + '</div></div></div>'));

    $actioncell = $('<div class="action"></div>');

    $morebutton = $('<img class="more button ro" src="../assets/img/buttons/morebutton_up.png" />');
    $morebutton.click(function() {

        $(this).parent().parent().find(".expander").slideDown();
        $(this).hide();
        $(this).parent().parent().find(".less").show();
    });

    $lessbutton = $('<img class="less button ro" src="../assets/img/buttons/lessbutton_up.png" />').hide();
    $lessbutton.click(function() {

        $(this).parent().parent().find(".expander").slideUp();
        $(this).hide();
        $(this).parent().parent().find(".more").show();
    });

    var $button;

    if (item.DisplayStatus == 3) {
        $button = $('<img class="show button ro" id="' + item.Id + '" src="../assets/img/buttons/showbutton_up.png" />');
        $button.click(function() { ModerateItemClick("show", this.id) });
    }
    else {
        $button = $('<img class="hide button ro" id="' + item.Id + '" src="../assets/img/buttons/hidebutton_up.png" />');
        $button.click(function() { ModerateItemClick("hide", this.id) });
    }

    $deletebutton = $('<img class="deletebutton button ro" id="' + item.Id + '" src="../assets/img/buttons/deletebutton_up.png" />');
    $deletebutton.click(function() { ModerateItemClick("delete", this.id) });
   
    $actioncell.append($button);
    $actioncell.append($deletebutton);
    $actioncell.append($morebutton);
    $actioncell.append($lessbutton);

    $row.append($actioncell);

    $row.append($('<div style="clear:both;float:none;"/>'));

    if (item.DisplayStatus == 3) {
        $row.addClass("unmoderated");
    }

    $("#TemplateItemsHolder").append($row);

    $row = null;

}

ModerateItemClick = function(operation, id) {

    $("body").data("id", id);

    var parameterObject = '{"Operation":"' + operation + '", "ID":"' + id + '"}';

    if (operation == "delete") {
        if (window.confirm("Sure you want to delete this?")) {
            AjaxManager(parameterObject, "AdminService.asmx/ModerateFeedItem", ItemDeleted, AjaxFailure);
        }
    }
    if (operation == "show") {
        AjaxManager(parameterObject, "AdminService.asmx/ModerateFeedItem", ItemShown, AjaxFailure);
    }
    if (operation == "hide") {
        AjaxManager(parameterObject, "AdminService.asmx/ModerateFeedItem", ItemHidden, AjaxFailure);
    }

}

ItemDeleted = function() {

    LoadAndRenderItems();
}

ItemHidden = function() {

    ChangeItemVisibility("show");
}

ItemShown = function() {

    ChangeItemVisibility("hide");
}

ChangeItemVisibility = function(visibilitystate) {

    if (visibilitystate == "show") {
        $("." + $("body").data("id")).addClass("unmoderated");
    }
    else {
        $("." + $("body").data("id")).removeClass("unmoderated");
    }

    var $button = $('<img class="' + visibilitystate + ' button ro" id="' + $("body").data("id") + '" src="../assets/img/buttons/' + visibilitystate + 'button_up.png" />');
    $button.click(function() { ModerateItemClick(visibilitystate, this.id) });

    var $deletebutton = $('<img class="deletebutton button ro" id="' + $("body").data("id") + '" src="../assets/img/buttons/deletebutton_up.png" />');
    $deletebutton.click(function() { ModerateItemClick("delete", this.id) });

    $("." + $("body").data("id") + " .action").empty().append($button).append($deletebutton);

    var ishidden = $("." + $("body").data("id") + " .expander").is(":hidden");

    $morebutton = $('<img class="more button ro" src="../assets/img/buttons/morebutton_up.png" />');
    $morebutton.click(function() {

        $(this).parent().parent().find(".expander").slideDown();
        $(this).hide();
        $(this).parent().parent().find(".less").show();
    });

    $lessbutton = $('<img class="less button ro" src="../assets/img/buttons/lessbutton_up.png" />');
    $lessbutton.click(function() {

        $(this).parent().parent().find(".expander").slideUp();
        $(this).hide();
        $(this).parent().parent().find(".more").show();
    });   

    if (ishidden) {
        $("." + $("body").data("id") + " .action").append($morebutton).append($lessbutton.hide());
    }
    else {
        $("." + $("body").data("id") + " .action").append($morebutton.hide()).append($lessbutton);
    }

}


