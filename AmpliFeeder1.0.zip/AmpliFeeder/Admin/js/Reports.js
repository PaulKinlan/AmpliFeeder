﻿$(document).ready(function() { LoadAndRenderItems() });

LoadAndRenderItems = function() {
    $('#channelstatusactivity').show();
    var parameterObject = '{}';
    AjaxManager(parameterObject, "../UIService.asmx/GetEnabledChannels", RenderChannels, AjaxFailure);

}

RenderChannels = function(data) {

    var items = eval('(' + data.d + ')');

    $("#channelstatus").hide();
    $.each(items, function(i, item) { $("#channelstatus table").append(RenderItem(item)); });

    $("#channelstatus").show();

    $("#channelstatus tr:even").addClass("evenrow");
    $('#channelstatusactivity').hide();

    RenderButtonRollovers();
}

RenderItem = function(item) {

$row = $('<tr><td>' + item.Title + '</td><td>' + item.FeedStatus + '</td><td>' + item.LastUpdated + '</td></tr>');

    return $row;
}

