﻿/// <reference path="jquery.intellisense.js"/>
$(document).ready(function() {

    InitPage();
});

InitPage = function() {

    GetChannels();

    $(".button").mouseover(function() { document.body.style.cursor = "pointer" }).mouseout(function() { document.body.style.cursor = "auto" })
    $("#channelcancelbutton").click(function() { ClickCancel() });
    $("#channelsubmitbutton").click(function() { ClickSubmit() });
    $("#channelremovebutton").click(function() { ClickRemove() });
    $("#channeldeletebutton").click(function() { ClickDelete() });
    

    RenderButtonRollovers();
}

GetChannels = function() {

    $("#channelform").hide();
    $("#channeldisplay").show();
    $("#addinstructions").show();
    $("#busyalert").hide();
    $('.activity').show();
    $('.channellist').empty();
    var parameterObject = '{}';
    AjaxManager(parameterObject, "AdminService.asmx/GetChannels", RenderChannels, AjaxFailure);
}

RenderChannels = function(data) {

    var items = eval('(' + data.d + ')');
   
    $('.activity').hide();

    $channel = $('<li><div class="channel"><div class="channelicon"><img src="../Assets/img/icons/24/customRSS20.png" alt="channel icon" /></div><div class="channeltitle"><a href="#">Add A Custom Channel</a></div></div></li>');
    $channel.click(function() { ClickAddNew() });
    $("#availablechannellist ul").append($channel);
    
    $.each(items, function(i, item) {
        if (item.IsEnabled == false) {
            $("#availablechannellist ul").append(BuildChannel(item));
        }
        else {
            $("#installedchannellist ul").append(BuildChannel(item));
        }
    });
}

BuildChannel = function(item) {

    $channel = $('<li><div class="channel"><div class="channelicon"><img src="../Assets/img/icons/24/' + item.SourceTypeName + '.png" alt="channel icon" /></div><div class="channeltitle"><a href="#">' + item.Title + '</a></div></div></li>');
    $channel.data("IsEnabled", item.IsEnabled);
    $channel.data("IsCustomSource", item.IsCustomSource);
    $channel.data("Id", item.Id);
    $channel.data("FeedParameterInstructions", item.Help);
    $channel.data("FeedParameter", item.FeedParameter);
    $channel.data("Title", item.Title);
    $channel.data("LastUpdated", item.LastUpdated);
    $channel.data("FeedStatus", item.FeedStatus);
    $channel.click(function() { ChannelClick(this) });

    return $channel;
}

ChannelClick = function(channel) {

    var IsEnabled = $(channel).data("IsEnabled");
    var IsCustomSource = $(channel).data("IsCustomSource");
    var Id = $(channel).data("Id");
    var FeedParameterInstructions = $(channel).data("FeedParameterInstructions");
    var FeedParameter = $(channel).data("FeedParameter");
    var Title = $(channel).data("Title");
    var LastUpdated = $(channel).data("LastUpdated");
    var FeedStatus = $(channel).data("FeedStatus");
    
    $("#channelform").data("Id", Id);
    $("#channelform").data("IsCustomSource", IsCustomSource);
    $("#channelform").data("IsEnabled", IsEnabled);
    $("#channelform").data("Title", Title);

    $("#channelform").show();
    $("#channeldisplay").hide();
    $("#addinstructions").hide();
    $(".alertbox").hide();

    $("#param").val(FeedParameter);
    $("#title").val(Title);

    if (IsEnabled) {
        $("#channeledittitle").html("Edit Channel");
        $("#channelremovebutton").show();
    }
    else {
        $("#channeledittitle").html("Install Channel");
        $("#channelremovebutton").hide();
    }

    if (IsCustomSource) {

        $("#channelinstructions").html("Please enter the URL of the RSS or Atom feed you wish to add. If you do not know the exact URL of the feed, enter the URL of the page where a feed may be found and we will try to calculate the feed URL.");
        $("#customchanneloptions").show();
        $("#channeldeletebutton").show();
    }
    else {
        $("#channelinstructions").html(FeedParameterInstructions);
        $("#customchanneloptions").hide();
        $("#channeldeletebutton").hide();
    }
}

ClickAddNew = function() {

    $("#channeledittitle").html("Install New Channel");
    $("#customchanneloptions").show();
    $("#channelform").show();
    $("#channeldisplay").hide();
    $("#addinstructions").hide();
    $("#channeldeletebutton").hide();
    $("#channelremovebutton").hide();
    $("#channelinstructions").html("Please enter the URL of the RSS or Atom feed you wish to add. If you do not know the exact URL of the feed, enter the URL of the page where a feed may be found and we will try to calculate the feed URL.");
    $("#param").val("");
    $("#title").val("");
    $(".alertbox").hide();
    $("#channelform").data("Id", "");
    $("#channelform").data("IsCustomSource", true);
}

ClickCancel = function() {

    $("#channelform").hide();
    $("#channeldisplay").show();
    $("#addinstructions").show();  
}

ClickSubmit = function() {


    var IsCustomSource = $("#channelform").data("IsCustomSource");
    var IsEnabled = $("#channelform").data("IsEnabled");
    var param = $("#param").val();
    param = param.replace(/^\s*|\s*$/, "");
    var title = $("#title").val();
    var Id = $("#channelform").data("Id");

    if (IsCustomSource) {

        if (param.length == 0 || title.length == 0) {
            $(".alertbox").html("Please complete both fields to submit.").show();
            return;
        }

        $("#busyalert").show();

        if (Id.length == 0) {
            AddCustomChannel(param, title);
        }
        else {
            EnableCustomChannel(Id, param, title);
        }
    }
    else {

        if (param.length == 0) {
            $(".alertbox").html("Please complete the field to submit.").show();
            return;
        }

        $("#busyalert").show();
        $(".alertbox").hide();

        EnableChannel(Id, param);
    }
}

EnableChannel = function(Id, param) {

    var parameterObject = '{"ID":"' + Id + '", "param":"' + param + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/EnableChannel", ChannelModified, AjaxFailure);
}

EnableCustomChannel = function(Id, param, title) {

    var parameterObject = '{"ID":"' + Id + '", "Name":"' + title + '", "uri":"' + param + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/EnableCustomChannel", ChannelModified, AjaxFailure);
}

AddCustomChannel = function(param, title) {

    var parameterObject = '{"Name":"' + title + '", "uri":"' + param + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/AddCustomChannel", ChannelModified, AjaxFailure);
}

ChannelModified = function(msg) {

$("#busyalert").hide();
    
    var result = msg.d;

    if (result == true) {
        GetChannels();
    }
    else {

        $(".alertbox").html("Unable to register that feed. Either it can't be found from the URL specified, the feed doesn't exist or the feed cannot be consumed.").show();
    }
}

ClickRemove = function() {

    var Id = $("#channelform").data("Id");
    $("#busyalert").show();
    var parameterObject = '{"ID":"' + Id + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/DisableChannel", GetChannels, AjaxFailure);
}

ClickDelete = function() {

    if (window.confirm("Sure you want to delete this?")) {
        var Id = $("#channelform").data("Id");
        $("#busyalert").show();
        var parameterObject = '{"ID":"' + Id + '"}';
        AjaxManager(parameterObject, "AdminService.asmx/DeleteChannel", GetChannels, AjaxFailure);
    }
}

