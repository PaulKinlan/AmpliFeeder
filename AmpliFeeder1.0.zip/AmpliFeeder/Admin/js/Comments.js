﻿/// <reference path="jquery.intellisense.js"/>
/// <reference path="Pager.js"/>

var PageSize = 10;
var PageNumber = 1;
var PageCount;

$(document).ready(function() {LoadAndRenderComments()});

LoadAndRenderComments = function() {

    var parameterObject = '{"PageSize":"' + PageSize + '", "PageNumber":"' + PageNumber + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/GetCommentsPackage", RenderComments, AjaxFailure);
}

RenderComments = function(data) {

    var items = eval('(' + data.d + ')');

    if (items.Comments.length == 0) {
        $("#firstaddalertbox").show();
        $(".commentstable").hide();
    }
    else {
        $("#firstaddalertbox").hide();
        $(".commentstable").show();
    }

    PageCount = items.CommentPageCount;

    $("#TemplateItemsHolder").empty();

    $.each(items.Comments, function(i, item) { RenderComment(item); });

    $("#pager").pager({ pagenumber: PageNumber, pagecount: PageCount, buttonClickCallback: PagerClick });

    $(".contentcell .row:even").addClass("evenrow");

    RenderButtonRollovers();
}

PagerClick = function(pageclickednumber) {

    $("#TemplateItemsHolder").empty();
    $("#TemplateItemsHolder").append('<img src="../Assets/img/activity2.gif" />');
    PageNumber = pageclickednumber;
    LoadAndRenderComments();
}

RenderComment = function(item) {

    $row = $('<div class="row ' + item.Id + '"></div>');
    $row.append($('<div class="comment cell"><div class="admindetail"><span class="adminlabel">Date:</span>' + item.Date + '</div><div class="admindetail"><span class="adminlabel">From:</span>' + item.Name + '</div><div class="admindetail"><span class="adminlabel">Email:</span><a href="mailto:' + item.Email + '">' + item.Email + '</a></div><div class="admindetail"><span class="adminlabel">Regarding:</span>' + item.AggregatedWeb20ItemTitle + '</div><div class="admindetail"><span class="adminlabel">Comment:</span>' + item.CommentBody + '</div></div>'));

    $actioncell = $('<div class="action cell"></div>');

    var $button;

    if (item.DisplayStatus == 3) {
        $button = $('<img class="button ro" id="' + item.Id + '" src="../assets/img/buttons/showbutton_up.png" />').click(function() { ModerateComment("show", this.id) });
    }
    else {
        $button = $('<img class="button ro" id="' + item.Id + '" src="../assets/img/buttons/hidebutton_up.png" />').click(function() { ModerateComment("hide", this.id) });
    }

    $deletebutton = $('<img class="deletebutton button ro" id="' + item.Id + '" src="../assets/img/buttons/deletebutton_up.png" />').click(function() { ModerateComment("delete", this.id) });

    $actioncell.append($button).append($deletebutton);

    $row.append($actioncell).append($('<div style="clear:both;float:none;"/>'));

    if (item.DisplayStatus == 3) {
        $row.addClass("unmoderated");
    }

    $("#TemplateItemsHolder").append($row);
}

ModerateComment = function(operation, id) {

    $("body").data("id", id);
    var parameterObject = '{"Operation":"' + operation + '", "ID":"' + id + '"}';

    if (operation == "delete") {
        if (window.confirm("Sure you want to delete this?")) {
            AjaxManager(parameterObject, "AdminService.asmx/ModerateComment", ItemDeleted, AjaxFailure);
        }
    }
    if (operation == "hide") {
        AjaxManager(parameterObject, "AdminService.asmx/ModerateComment", ItemHidden, AjaxFailure);
    }
    if (operation == "show") {
        AjaxManager(parameterObject, "AdminService.asmx/ModerateComment", ItemShown, AjaxFailure);
    }
}

ItemDeleted = function() {
    LoadAndRenderComments();
}

ItemHidden = function() {

    ChangeItemVisibility("show");
}

ItemShown = function() {

    ChangeItemVisibility("hide");
}

ChangeItemVisibility = function(visibilitystate) {
    
    if (visibilitystate == "show") {
        $("." + $("body").data("id")).addClass("unmoderated");
    }
    else {
        $("." + $("body").data("id")).removeClass("unmoderated");
    }

    var $button = $('<img class="' + visibilitystate + ' button ro" id="' + $("body").data("id") + '" src="../assets/img/buttons/' + visibilitystate + 'button_up.png" />');
    $button.click(function() { ModerateComment(visibilitystate, this.id) });

    var $deletebutton = $('<img class="deletebutton button ro" id="' + $("body").data("id") + '" src="../assets/img/buttons/deletebutton_up.png" />');
    $deletebutton.click(function() { ModerateComment("delete", this.id) });

    $("." + $("body").data("id") + " .action").empty().append($button).append($deletebutton);
    $("." + $("body").data("id") + " .action").append($deletebutton);
}


