﻿/// <reference path="jquery.intellisense.js"/>
/// <reference path="Pager.js"/>

var editmode;
var PageSize = 5;
var PageNumber = 1;
var PageCount;

$(document).ready(function() { InitialiseMicroblog(); LoadAndRenderMicroblog(); });

InitialiseMicroblog = function() {

    $("#newpostform").hide();
    $("#submitButton").click(function() { SubmitClick() });
    $("#addButton").click(function() { AddClick() });
    $("#firstaddbutton").click(function() { AddClick() });
    $("#cancelButton").click(function() { CancelClick() });
    $(".button").mouseover(function() { document.body.style.cursor = "pointer" }).mouseout(function() { document.body.style.cursor = "auto" });
    $(".alertbox").hide();
}

LoadAndRenderMicroblog = function() {

    var parameterObject = '{"PageSize":"' + PageSize + '", "PageNumber":"' + PageNumber + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/GetMicroblogPackage", RenderMicroBlog, AjaxFailure);
}

RenderMicroBlog = function(data) {

    $("#TemplateItemsHolder").empty();

    var items = eval('(' + data.d + ')');

    PageCount = items.PageCount;

    $.each(items.FeedItems, function(i, item) { RenderItem(item); });

    if (items.FeedItems.length == 0) {
        $("#ListAreaWrapper").hide();
        $("#firstaddalertbox").show();
    }
    else {
        $("#firstaddalertbox").hide();
    }

    $("#pager").pager({ pagenumber: PageNumber, pagecount: PageCount, buttonClickCallback: PagerClick });

    $(".contentcell .row:even").addClass("evenrow");

    RenderButtonRollovers();
    $("#newpostform").hide();
}

PagerClick = function(pageclickednumber) {

    $("#TemplateItemsHolder").empty();
    $("#TemplateItemsHolder").append('<img src="../Assets/img/activity2.gif" />');
    PageNumber = pageclickednumber;
    LoadAndRenderMicroblog();
}

RenderItem = function(item) {

    $row = $('<div class="row ' + item.Id + '"></div>');

    $row.append($('<div class="microblogitem cell"><div class="admindetail"><span class="adminlabel">Title:</span>' + item.Title + '</div><div class="admindetail"><span class="adminlabel">Dated:</span>' + item.Date + '</div><div class="admindetail"><span class="adminlabel">Post:</span>' + item.Description + '</div></div>'));

    $actioncell = $('<span class="microblogaction cell"></span>');

    var $button;

    if (item.DisplayStatus == 3) {
        $button = $('<img class="button ro" id="' + item.Id + '" src="../assets/img/buttons/showbutton_up.png" />');
        $button.click(function() { ModerateItem("show", this.id) });
    }
    else {
        $button = $('<img class="button ro" id="' + item.Id + '" src="../assets/img/buttons/hidebutton_up.png" />');
        $button.click(function() { ModerateItem("hide", this.id) });
    }

    $deletebutton = $('<img class="deletebutton button ro" id="' + item.Id + '" src="../assets/img/buttons/deletebutton_up.png" />');
    $deletebutton.click(function() { ModerateItem("delete", this.id) });

    $editbutton = $('<img class="editbutton ro" id="' + item.Id + '" src="../assets/img/buttons/editbutton_up.png" />');
    $editbutton.click(function() { EditClick(this.id, item.Title,item.Description) });

    $actioncell.append($button);
    $actioncell.append($deletebutton);
    

    $row.append($actioncell);
    $row.append($editbutton);
    
    $row.append($('<div style="clear:both;float:none;"/>'));

    if (item.DisplayStatus == 3) {
        $row.addClass("unmoderated");
    }

    $("#TemplateItemsHolder").append($row);
}

SubmitClick = function() {

    var validated = true;

    if ($("#posttitle").val().length == 0) {
        validated = false;
    }

    tinyMCE.triggerSave(true, true);

    var postBody = $("#postbody").val();

    if ($("#postbody").val().length == 0) {
        validated = false;
    }

    if (validated == false) {
        $(".alertbox").html("Sorry, both the post title and post body must be filled in before you can submit a new post.").show();
        return;
    }

    PersistPost();

    $("#posttitle").val("");
    $("#postbody").text("");

    $("#newpostform").hide();
    $("#addnewpost").show();
    $(".alertbox").hide();
    $("#itemArea").show();
    $("#ListAreaWrapper").show();

}

AddClick = function() {

    $("body").data("editID", "");
    $("#addnewpost").hide();
    $("#newpostform").show();
    editmode = "new";
    $("#radiobuttonlist").hide();
    $("#posttitle").val("");
    tinyMCE.activeEditor.setContent("");
    $("#itemArea").hide();
    $(".alertbox").hide();
}

CancelClick = function() {

    $("#addnewpost").show();
    $("#newpostform").hide();
    $("#itemArea").show();
    editmode = null;
}

EditClick = function(editID, title, description) {

    $("body").data("editID", editID);
    $("#addnewpost").hide();
    $("#newpostform").show();
    $("#posttitle").val(title);
    tinyMCE.activeEditor.setContent(description);
    $("#itemArea").hide();
    $("#radiobuttonlist").show();
    editmode = "edit";
    $(".alertbox").hide();
}

PersistPost = function() {

    editmode == "edit" ? UpdateItem() : SaveItem();
}

SaveItem = function() {

    title = $("#posttitle").val();
    body = $("#postbody").val();

    var parameterObject = '{"Title":"' + title + '", "Body":"' + body + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/SaveNewMicroBlogPost", MicroBlogPostChanged, AjaxFailure);
}

UpdateItem = function() {

    title = $("#posttitle").val();
    body = $("#postbody").val();
    setnewdate = $("#newdate").attr("checked");
    id = $("body").data("editID");

    var parameterObject = '{"Title":"' + title + '", "Body":"' + body + '", "Id":"' + id + '", "SetNewDate":"' + setnewdate + '"}';
    AjaxManager(parameterObject, "AdminService.asmx/UpdateMicroBlogPost", MicroBlogPostChanged, AjaxFailure);
}

ModerateItem = function(operation, id) {

    $("body").data("id", id);

    var parameterObject = '{"Operation":"' + operation + '", "ID":"' + id + '"}';

    if (operation == "delete") {
        if (window.confirm("Sure you want to delete this?")) {
            AjaxManager(parameterObject, "AdminService.asmx/ModerateFeedItem", ItemDeleted, AjaxFailure);
        }
    }
    if (operation == "show") {
        AjaxManager(parameterObject, "AdminService.asmx/ModerateFeedItem", ItemShown, AjaxFailure);
    }
    if (operation == "hide") {
        AjaxManager(parameterObject, "AdminService.asmx/ModerateFeedItem", ItemHidden, AjaxFailure);
    }

}

ItemDeleted = function() {

LoadAndRenderMicroblog();
}

ItemHidden = function() {

    ChangeItemVisibility("show");
}

ItemShown = function() {

    ChangeItemVisibility("hide");
}

ChangeItemVisibility = function(visibilitystate) {

    if (visibilitystate == "show") {
        $("." + $("body").data("id")).addClass("unmoderated");
    }
    else {
        $("." + $("body").data("id")).removeClass("unmoderated");
    }

    var $button = $('<img class="' + visibilitystate + ' button ro" id="' + $("body").data("id") + '" src="../assets/img/buttons/' + visibilitystate + 'button_up.png" />');
    $button.click(function() { ModerateItem(visibilitystate, this.id) });

    var $deletebutton = $('<img class="deletebutton button ro" id="' + $("body").data("id") + '" src="../assets/img/buttons/deletebutton_up.png" />');
    $deletebutton.click(function() { ModerateItem("delete", this.id) });

    $("." + $("body").data("id") + " .microblogaction").empty().append($button).append($deletebutton);
}

MicroBlogPostChanged = function() {

    LoadAndRenderMicroblog();
}

