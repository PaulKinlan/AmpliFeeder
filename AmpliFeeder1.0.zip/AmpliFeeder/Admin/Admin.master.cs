﻿/*
    _                    _ _ _____             _           
   / \   _ __ ___  _ __ | (_)  ___|__  ___  __| | ___ _ __ 
  / _ \ | '_ ` _ \| '_ \| | | |_ / _ \/ _ \/ _` |/ _ \ '__|
 / ___ \| | | | | | |_) | | |  _|  __/  __/ (_| |  __/ |   
/_/   \_\_| |_| |_| .__/|_|_|_|  \___|\___|\__,_|\___|_|   
                  |_|        
 * AmpliFeeder v1.0
 * AmpliFeeder is (C) Jon Paul Davies 2009 jonpauldavies@gmail.com
 * http://www.twitter.com/jonpauldavies
 * 
 * AmpliFeeder is available under the GNU Affero General Public License 
 * (or AGPL for short),a version of the GNU GPL designed specifically 
 * for web applications. All trademarks, slogans, text or logo represented, 
 * used or infered to in this application are the property of their respective owners. 
 * 
 * AGPL: http://www.fsf.org/licensing/licenses/agpl-3.0.html
*/

using System;
using System.Web.Security;
using System.Web.UI;

public partial class Admin_Admin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void Logout_click(object sender, ImageClickEventArgs e)
    {
        FormsAuthentication.SignOut();
        Session.Abandon();
        Response.Redirect("../Default.aspx");
    }
}
