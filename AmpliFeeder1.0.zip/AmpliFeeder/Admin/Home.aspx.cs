﻿/*
    _                    _ _ _____             _           
   / \   _ __ ___  _ __ | (_)  ___|__  ___  __| | ___ _ __ 
  / _ \ | '_ ` _ \| '_ \| | | |_ / _ \/ _ \/ _` |/ _ \ '__|
 / ___ \| | | | | | |_) | | |  _|  __/  __/ (_| |  __/ |   
/_/   \_\_| |_| |_| .__/|_|_|_|  \___|\___|\__,_|\___|_|   
                  |_|        
 * AmpliFeeder v1.0
 * AmpliFeeder is (C) Jon Paul Davies 2009 jonpauldavies@gmail.com
 * http://www.twitter.com/jonpauldavies
 * 
 * AmpliFeeder is available under the GNU Affero General Public License 
 * (or AGPL for short),a version of the GNU GPL designed specifically 
 * for web applications. All trademarks, slogans, text or logo represented, 
 * used or infered to in this application are the property of their respective owners. 
 * 
 * AGPL: http://www.fsf.org/licensing/licenses/agpl-3.0.html
*/

using System;
using System.Net;

public partial class Admin_Home : System.Web.UI.Page
{
    public string readme;
    public string video;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Cache["readme"] == null)
            {
                WebClient wc = new WebClient();

                Cache.Insert("readme", wc.DownloadString("http://www.amplifeeder.com/homecontent/readme.html"), null, DateTime.Now.AddDays(7), System.Web.Caching.Cache.NoSlidingExpiration);
                Cache.Insert("video", wc.DownloadString("http://www.amplifeeder.com/homecontent/video.html"), null, DateTime.Now.AddDays(7), System.Web.Caching.Cache.NoSlidingExpiration);
            }

            readme = Cache["readme"].ToString();
            video = Cache["video"].ToString();
        }
        catch(Exception ex)
        {
            readme = "<h4>Cannot update Home content at this time.</h4> An exception was thrown and the reason given was <b>" +
                     ex.Message + "</b>";
        }

    }
}
