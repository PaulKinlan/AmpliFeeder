﻿/*
    _                    _ _ _____             _           
   / \   _ __ ___  _ __ | (_)  ___|__  ___  __| | ___ _ __ 
  / _ \ | '_ ` _ \| '_ \| | | |_ / _ \/ _ \/ _` |/ _ \ '__|
 / ___ \| | | | | | |_) | | |  _|  __/  __/ (_| |  __/ |   
/_/   \_\_| |_| |_| .__/|_|_|_|  \___|\___|\__,_|\___|_|   
                  |_|        
 * AmpliFeeder v1.0
 * AmpliFeeder is (C) Jon Paul Davies 2009 jonpauldavies@gmail.com
 * http://www.twitter.com/jonpauldavies
 * 
 * AmpliFeeder is available under the GNU Affero General Public License 
 * (or AGPL for short),a version of the GNU GPL designed specifically 
 * for web applications. All trademarks, slogans, text or logo represented, 
 * used or infered to in this application are the property of their respective owners. 
 * 
 * AGPL: http://www.fsf.org/licensing/licenses/agpl-3.0.html
*/

using System;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Design : System.Web.UI.Page
{
    readonly UIService uiservice = new UIService();
    readonly AdminService adminservice = new AdminService();

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            GetThemeNames();

            string currentThemeName = CurrentThemeName();

            ddlThemes.SelectedValue = currentThemeName;
            ddlThemes.DataBind();

            lblTheme.Text = currentThemeName;
            imgTheme.ImageUrl = "~/Themes/" + currentThemeName + "/preview.png";

        }
    }

    protected void GetThemeNames()
    {
        ddlThemes.Items.Clear();

        var dirs = new DirectoryInfo(Server.MapPath("~/Themes/"));

        foreach (DirectoryInfo dir in dirs.GetDirectories())
        {
            ddlThemes.Items.Add(new ListItem(dir.Name));
        }
    }

    private string CurrentThemeName()
    {
        string themename = uiservice.GetCurrentThemeName();

        return themename;
    }

    protected void btnTheme_Click(object sender, ImageClickEventArgs e)
    {
        adminservice.SetThemeName(ddlThemes.SelectedValue);

        Application["ThemeName"] = ddlThemes.SelectedValue;

        ManagePanels(pnlOK);
        lblOK.Text = "Theme Updated.";

        string currentThemeName = ddlThemes.SelectedValue;

        lblTheme.Text = currentThemeName;
        imgTheme.ImageUrl = "~/Themes/" + currentThemeName + "/preview.png";
    }

    private void ManagePanels(Panel visiblepanel)
    {
        pnlOK.Visible = false;
        pnlAlert.Visible = false;
        visiblepanel.Visible = true;
    }

    protected void btnCSS_Click(object sender, ImageClickEventArgs e)
    {
        adminservice.SetCustomCSS(txtCSS.Value);
    }
}
