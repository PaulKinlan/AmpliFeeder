﻿/*
    _                    _ _ _____             _           
   / \   _ __ ___  _ __ | (_)  ___|__  ___  __| | ___ _ __ 
  / _ \ | '_ ` _ \| '_ \| | | |_ / _ \/ _ \/ _` |/ _ \ '__|
 / ___ \| | | | | | |_) | | |  _|  __/  __/ (_| |  __/ |   
/_/   \_\_| |_| |_| .__/|_|_|_|  \___|\___|\__,_|\___|_|   
                  |_|        
 * AmpliFeeder v1.0
 * AmpliFeeder is (C) Jon Paul Davies 2009 jonpauldavies@gmail.com
 * http://www.twitter.com/jonpauldavies
 * 
 * AmpliFeeder is available under the GNU Affero General Public License 
 * (or AGPL for short),a version of the GNU GPL designed specifically 
 * for web applications. All trademarks, slogans, text or logo represented, 
 * used or infered to in this application are the property of their respective owners. 
 * 
 * AGPL: http://www.fsf.org/licensing/licenses/agpl-3.0.html
*/

using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using JDEE.AMPLIFEEDER.BLL.DataPortability;
using JDEE.AMPLIFEEDER.BLL.Utility;

public partial class Admin_Settings : Page
{
    readonly AdminService adminservice = new AdminService();
    readonly UIService uiservice = new UIService();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            LoadAPIKey();
            LoadSettings();
        }
    }

    private void LoadSettings()
    {
        Settings settings = uiservice.GetSettings();

        txtTitle.Value = settings.Title;
        txtTagline.Value = settings.Tagline;
        txtAbout.Value = settings.About;
    }

    private void SaveSettings(string title, string tagline,string about)
    {
        Settings settings=new Settings {Title = title, Tagline = tagline, About = about};

        adminservice.SaveDescription(settings);
    }

    private void LoadAPIKey()
    {
        yahookey.Value = adminservice.GetAPIKey();
    }

    protected void btnPassword_Click(object sender, ImageClickEventArgs e)
    {
        string result = adminservice.UpdatePassword(currentpassword.Value, newpassword.Value, newpasswordagain.Value,
                                           passwordhint.Value);

        if (! string.IsNullOrEmpty(result))
        {
            ManagePanels(pnlAlert);
            lblAlert.Text = result;
        }
        else
        {
            currentpassword.Value = string.Empty;
            newpassword.Value = string.Empty;
            newpasswordagain.Value = string.Empty;
            passwordhint.Value = string.Empty;
            ManagePanels(pnlOK);
            lblOK.Text = "Password Updated!";
        }
    }

    protected void btnKey_Click(object sender, ImageClickEventArgs e)
    {
        if (string.IsNullOrEmpty(yahookey.Value))
        {
            ManagePanels(pnlAlert);
            lblAlert.Text = "Please supply a valid key.";
            return;
        }

        adminservice.SetAPIKey(yahookey.Value);
        ManagePanels(pnlOK);
        lblOK.Text = "API Key Updated.";
    }

    protected void btnFriendFeed_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            adminservice.ConfigureFromFriendFeed(txtFriendFeedUsername.Value);
        }
        catch(Exception ex)
        {
            ManagePanels(pnlAlert);
            lblAlert.Text = "FriendFeed could not find an account by that name or had trouble returning the profile. An exception was raised and the message returned was: " + ex.Message; 
        }
    }

    protected void btnUpdate_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            JDEE.AMPLIFEEDER.BLL.FeedItems.FeedItemsToDatabase.GetFeeds();
            ManagePanels(pnlOK);
            lblOK.Text = "Channels updated!";
        }
        catch (Exception ex)
        {
            ManagePanels(pnlAlert);
            lblAlert.Text = "Could not update the feeds at this time as an exception occured. The reason given was: " + ex.Message;
        }
    }

    protected void DescriptionButton_Click(object sender, ImageClickEventArgs e)
    {
        SaveSettings(txtTitle.Value,txtTagline.Value,txtAbout.Value);

        ManagePanels(pnlOK);
        lblOK.Text = "Description Updated.";
    }

    private void ManagePanels(Panel visiblepanel)
    {
        pnlOK.Visible = false;
        pnlAlert.Visible = false;
        visiblepanel.Visible = true;
    }

    public void btnBackup_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            var dpm = new DataPortabilityManager();

            var file = dpm.GetFeed("backup");

            Response.Clear();
            Response.AddHeader("Content-Disposition", "attachment; filename=AmpliFeederBackup.xml");

            byte[] bytes = Encoding.UTF8.GetBytes(file);

            Response.AddHeader("Content-Length", bytes.Length.ToString());
            Response.ContentType = "application/octet-stream";
            Response.Write(file);
        }
        catch(Exception ex)
        {
            ManagePanels(pnlAlert);
            lblAlert.Text = "There was an error and the backup file creation failed for some reason. An exception was thrown and the reason given was: " + ex.Message; 
        }
    }

    public void btnRestore_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (FileUpload1.HasFile)
            {

                int fileLen = FileUpload1.PostedFile.ContentLength;

                Byte[] Input = new Byte[fileLen];

                var myStream = FileUpload1.FileContent;

                // Read the file into the byte array.
                myStream.Read(Input, 0, fileLen);

                string fileContents = Encoding.UTF8.GetString(Input);

                var dpm = new DataPortabilityManager();

                dpm.Restore(fileContents);

                ManagePanels(pnlOK);
                lblOK.Text = "Data restore from file OK";
            }
            else
            {
                ManagePanels(pnlAlert);
                lblAlert.Text = "No file was uploaded. Please check and try again.";
            }
        }
        catch (Exception ex)
        {
            ManagePanels(pnlAlert);
            lblAlert.Text = "There was an error and the restore from file failed for some reason. An exception was raised and the message was: " + ex.Message;
        }
    }

}


