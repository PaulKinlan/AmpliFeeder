﻿using System;
using System.Configuration;
using System.Net;
using System.Web.UI;
using JDEE.AMPLIFEEDER.BLL.Utility;

public partial class Configure : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (ConfigurationManager.AppSettings["setup"] == null || ConfigurationManager.AppSettings["setup"] != "true")
        {
            Response.Redirect("default.aspx");
        }
    }

    protected void btnPing_Click(object sender, EventArgs e)
    {
        AmpliPinger ampliPinger=new AmpliPinger();

        PopMessage(ampliPinger.Register(Request));
    }

    private void PopMessage(string message)
    {
        string alertscript = "<script language=javascript>";
        alertscript = alertscript + "alert('"+ message + "');";
        alertscript = alertscript + "</script>";
        ClientScript.RegisterClientScriptBlock(typeof(Page), "Message From AmpliPinger Service", alertscript);

    }
}
