﻿/*
    _                    _ _ _____             _           
   / \   _ __ ___  _ __ | (_)  ___|__  ___  __| | ___ _ __ 
  / _ \ | '_ ` _ \| '_ \| | | |_ / _ \/ _ \/ _` |/ _ \ '__|
 / ___ \| | | | | | |_) | | |  _|  __/  __/ (_| |  __/ |   
/_/   \_\_| |_| |_| .__/|_|_|_|  \___|\___|\__,_|\___|_|   
                  |_|        
 * AmpliFeeder v1.0
 * AmpliFeeder is (C) Jon Paul Davies 2009 jonpauldavies@gmail.com
 * http://www.twitter.com/jonpauldavies
 * 
 * AmpliFeeder is available under the GNU Affero General Public License 
 * (or AGPL for short),a version of the GNU GPL designed specifically 
 * for web applications. All trademarks, slogans, text or logo represented, 
 * used or infered to in this application are the property of their respective owners. 
 * 
 * AGPL: http://www.fsf.org/licensing/licenses/agpl-3.0.html
*/

using System;
using System.Collections;
using System.Web.Script.Serialization;
using System.Web.Services;
using JDEE.AMPLIFEEDER.BLL.Channels;
using JDEE.AMPLIFEEDER.BLL.Comments;
using JDEE.AMPLIFEEDER.BLL.FeedItems;
using JDEE.AMPLIFEEDER.BLL.FriendFeed;
using JDEE.AMPLIFEEDER.BLL.MicroBlog;
using JDEE.AMPLIFEEDER.BLL.Utility;

/// <summary>
/// Summary description for AdminService
/// </summary>
[WebService(Namespace = "http://amplifeeder.com/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.Web.Script.Services.ScriptService]
public class AdminService : System.Web.Services.WebService
{
    public ArrayList GetChannelActivityData()
    {
        var channelmanager = new ChannelManager();

        return channelmanager.GetChannelActivityData();
    }

    [WebMethod]
    public string GetChannels()
    {
        var manager = new ChannelManager();

        var sources = manager.GetChannels();

        var jss = new JavaScriptSerializer();

        return jss.Serialize(sources);
    }

    [WebMethod]
    public bool AddCustomChannel(string Name, string uri)
    {
        var manager = new ChannelManager();

        return manager.AddCustomChannel(Name, uri);
    }

    [WebMethod]
    public bool EnableChannel(string ID, string param)
    {

        var manager = new ChannelManager();

        return manager.EnableChannel(new Guid(ID), param);
    }

    [WebMethod]
    public bool EnableCustomChannel(string ID, string Name, string uri)
    {
        var manager = new ChannelManager();

        return manager.EnableCustomChannel(new Guid(ID), Name, uri);
    }

    [WebMethod]
    public void DisableChannel(string ID)
    {

        var manager = new ChannelManager();

        manager.DisableChannel(new Guid(ID));
    }

    [WebMethod]
    public void DeleteChannel(string ID)
    {

        var manager = new ChannelManager();

        manager.DeleteChannel(new Guid(ID));
    }

    [WebMethod]
    public string GetCommentsPackage(int PageSize, int PageNumber)
    {
        var manager = new CommentManager();

        var package = new CommentListDisplayPackage();

        package.Comments = manager.GetCommentsForModeration(PageSize, PageNumber);
        package.CommentPageCount = manager.GetCommentsForModerationPageCount(PageSize);

        var jss = new JavaScriptSerializer();

        return jss.Serialize(package);
    }

    [WebMethod]
    public void ModerateComment(string Operation, string ID)
    {
        var moderator = new Moderator();

        moderator.Moderate(new CommentManager(), Operation, ID);
    }

    [WebMethod]
    public string GetItemsForModerationPackage(int PageSize, int PageNumber)
    {

        var reader = new FeedItemManager();

        var package = new FeedItemListDisplayPackage();

        package.FeedItems = reader.GetFeedItemsForModeration(PageSize, PageNumber);
        package.PageCount = reader.GetFeedItemsForModerationPageCount(PageSize);

        var jss = new JavaScriptSerializer();

        return jss.Serialize(package);

    }

    [WebMethod]
    public void ModerateFeedItem(string Operation, string ID)
    {
        var moderator = new Moderator();

        moderator.Moderate(new FeedItemManager(), Operation, ID);

    }

    [WebMethod]
    public string GetMicroblogPackage(int PageSize, int PageNumber)
    {

        var reader = new MicroBlogManager();

        var package = new FeedItemListDisplayPackage();

        package.FeedItems = reader.GetMicroblogForModeration(PageSize, PageNumber);
        package.PageCount = reader.GetMicroblogForModerationCount(PageSize);

        var jss = new JavaScriptSerializer();

        return jss.Serialize(package);
    }

    [WebMethod]
    public void SaveNewMicroBlogPost(string Title, string Body)
    {
        var manager = new MicroBlogManager();

        manager.SaveNewMicroBlogPost(Title, Body);
    }

    [WebMethod]
    public void UpdateMicroBlogPost(string Title, string Body, Guid Id, bool SetNewDate)
    {
        var manager = new MicroBlogManager();

        manager.UpdateMicroBlogPost(Title, Body, Id, SetNewDate);
    }



    public void SaveDescription(Settings settings)
    {
        SettingsManager manager = new SettingsManager();

        manager.SaveSettings(settings);
    }

    public void ConfigureFromFriendFeed(string username)
    {
        FriendFeedManager ffmanager = new FriendFeedManager();

        ffmanager.ConfigureFromFriendFeed(username);
    }

    public string UpdatePassword(string currentpassword, string newpassword, string newpasswordagain, string hint)
    {
        SettingsManager manager = new SettingsManager();

        return manager.UpdatePassword(Session["username"].ToString(), currentpassword, newpassword, newpasswordagain, hint);
    }

    public string GetAPIKey()
    {
        SettingsManager manager = new SettingsManager();

        return manager.GetAPIKey();
    }

    public void SetAPIKey(string apikey)
    {
        SettingsManager manager = new SettingsManager();

        manager.SetAPIKey(apikey);
    }

    public void SetThemeName(string themename)
    {
        SettingsManager manager = new SettingsManager();

        manager.SetThemeName(themename);
    }

    [WebMethod]
    public void SetCustomCSS(string customcss)
    {
        SettingsManager manager = new SettingsManager();

        manager.SetCustomCSS(customcss);
    }

}

