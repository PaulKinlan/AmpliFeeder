﻿/*
    _                    _ _ _____             _           
   / \   _ __ ___  _ __ | (_)  ___|__  ___  __| | ___ _ __ 
  / _ \ | '_ ` _ \| '_ \| | | |_ / _ \/ _ \/ _` |/ _ \ '__|
 / ___ \| | | | | | |_) | | |  _|  __/  __/ (_| |  __/ |   
/_/   \_\_| |_| |_| .__/|_|_|_|  \___|\___|\__,_|\___|_|   
                  |_|        
 * AmpliFeeder v1.0
 * AmpliFeeder is (C) Jon Paul Davies 2009 jonpauldavies@gmail.com
 * http://www.twitter.com/jonpauldavies
 * 
 * AmpliFeeder is available under the GNU Affero General Public License 
 * (or AGPL for short),a version of the GNU GPL designed specifically 
 * for web applications. All trademarks, slogans, text or logo represented, 
 * used or infered to in this application are the property of their respective owners. 
 * 
 * AGPL: http://www.fsf.org/licensing/licenses/agpl-3.0.html
*/

using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Web.Services;
using JDEE.AMPLIFEEDER.BLL.Comments;
using JDEE.AMPLIFEEDER.BLL.Enums;
using JDEE.AMPLIFEEDER.BLL.FeedItems;
using JDEE.AMPLIFEEDER.BLL.Channels;
using JDEE.AMPLIFEEDER.BLL.Tags;
using JDEE.AMPLIFEEDER.BLL.Utility;


/// <summary>
/// Summary description for UIService
/// </summary>
[WebService(Namespace = "http://amplifeeder.com/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.Web.Script.Services.ScriptService]
public class UIService : WebService
{
    [WebMethod]
    public string GetItems(int PageSize, int PageNumber, string ItemFilterType, string ItemFilterArgument)
    {

        var reader = new FeedItemManager();

        List<FeedItem> items = reader.GetFeedItems(PageSize, PageNumber, (EnumItemFilterType)Enum.Parse(typeof(EnumItemFilterType), ItemFilterType), ItemFilterArgument);

        var jss=new JavaScriptSerializer();

        return jss.Serialize(items);
       
    }

    [WebMethod]
    public string GetItemsPackage(int PageSize, int PageNumber, string ItemFilterType, string ItemFilterArgument)
    {

        var reader = new FeedItemManager();

        var package=new FeedItemListDisplayPackage();

        package.FeedItems = reader.GetFeedItems(PageSize, PageNumber, (EnumItemFilterType)Enum.Parse(typeof(EnumItemFilterType), ItemFilterType), ItemFilterArgument);
        package.PageCount = reader.GetPageCount(PageSize, (EnumItemFilterType)Enum.Parse(typeof(EnumItemFilterType), ItemFilterType), ItemFilterArgument);

        var jss = new JavaScriptSerializer();

        string result = jss.Serialize(package);
        return result;
    }

    [WebMethod]
    public string GetInitItemsPackage(int PageSize, int PageNumber, string ItemFilterType, string ItemFilterArgument)
    {

        var reader = new FeedItemManager();

        var package = new FeedItemListDisplayPackage();

        package.FeedItems = reader.GetFeedItems(PageSize, PageNumber, (EnumItemFilterType)Enum.Parse(typeof(EnumItemFilterType), ItemFilterType), ItemFilterArgument);
        package.PageCount = reader.GetPageCount(PageSize, (EnumItemFilterType)Enum.Parse(typeof(EnumItemFilterType), ItemFilterType), ItemFilterArgument);
        package.Settings = GetSettings();

        var jss = new JavaScriptSerializer();

        string result = jss.Serialize(package);
        return result;
    }

    [WebMethod]
    public int GetPageCount(int PageSize, string ItemFilterType, string ItemFilterArgument)
    {
        var reader = new FeedItemManager();

        int count = reader.GetPageCount(PageSize, (EnumItemFilterType)Enum.Parse(typeof(EnumItemFilterType), ItemFilterType), ItemFilterArgument);

        return count;
    }

    [WebMethod]
    public string GetTags(int TagPage)
    {
        var reader = new TagManager();

        List<Tag> items = reader.GetTags(TagPage);

        var jss = new JavaScriptSerializer();

        return jss.Serialize(items);
    }

    [WebMethod]
    public void SubmitComment(string itemID, string name,string email,string message)
    {
        var manager = new CommentManager();

        var comment = new Comment();

        comment.Id = Guid.NewGuid();
        comment.Name = name;
        comment.Email = email;
        comment.CommentBody = message;
        comment.DatePosted = DateTime.Now;
        comment.DisplayStatus = EnumDisplayStatus.Hidden;
        comment.ItemId = new Guid(itemID);
                       
        manager.SaveComment(comment);
    }

    [WebMethod]
    public string GetEnabledChannels()
    {
        var manager = new ChannelManager();

        var sources = manager.GetEnabledChannels();

        var jss = new JavaScriptSerializer();

        return jss.Serialize(sources);
    }

    [WebMethod]
    public string GetActiveSources()
    {
        var manager = new ChannelManager();

        var sources = manager.GetActiveChannels();

        var jss = new JavaScriptSerializer();

        return jss.Serialize(sources);
    }

    public string GetCurrentThemeName()
    {
        SettingsManager manager = new SettingsManager();

        return manager.GetCurrentThemeName();

    }

    [WebMethod]
    public string GetDetailItem(string itemID,int numberToReturn)
    {
        var package = new FeedItemListDisplayPackage();

        var feedmanager = new FeedItemManager();
        var channelmanager = new ChannelManager();
        var commentmanager = new CommentManager();
        var settingsmanager = new SettingsManager();

        package.Channel = channelmanager.GetChannel(new Guid(itemID));
        package.Item = feedmanager.GetFeedItem(new Guid(itemID));
        package.FeedItems = feedmanager.GetLatestChannelFeedItems(package.Channel, numberToReturn);
        package.Comments = commentmanager.GetApprovedComments(new Guid(itemID));
        package.Settings = settingsmanager.GetSettings();

        var jss = new JavaScriptSerializer();

        return jss.Serialize(package);
    }

    public Settings GetSettings()
    {
        SettingsManager manager = new SettingsManager();

        return manager.GetSettings();
    }

    [WebMethod]
    public string GetFeature(string itemtype, int numberToReturn)
    {
        var reader = new FeedItemManager();

        var jss = new JavaScriptSerializer();

        return jss.Serialize(reader.GetFeedItemsForFeature(itemtype, numberToReturn));
    }

}