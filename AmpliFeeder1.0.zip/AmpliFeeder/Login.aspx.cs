﻿/*
    _                    _ _ _____             _           
   / \   _ __ ___  _ __ | (_)  ___|__  ___  __| | ___ _ __ 
  / _ \ | '_ ` _ \| '_ \| | | |_ / _ \/ _ \/ _` |/ _ \ '__|
 / ___ \| | | | | | |_) | | |  _|  __/  __/ (_| |  __/ |   
/_/   \_\_| |_| |_| .__/|_|_|_|  \___|\___|\__,_|\___|_|   
                  |_|        
 * AmpliFeeder v1.0
 * AmpliFeeder is (C) Jon Paul Davies 2009 jonpauldavies@gmail.com
 * http://www.twitter.com/jonpauldavies
 * 
 * AmpliFeeder is available under the GNU Affero General Public License 
 * (or AGPL for short),a version of the GNU GPL designed specifically 
 * for web applications. All trademarks, slogans, text or logo represented, 
 * used or infered to in this application are the property of their respective owners. 
 * 
 * AGPL: http://www.fsf.org/licensing/licenses/agpl-3.0.html
*/

using System;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using JDEE.AMPLIFEEDER.BLL.Utility;

public partial class Login : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            failpanel.Visible = false;
            username.Focus();
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        UserManager manager = new UserManager();

        bool result = manager.TryLogon(username.Text, password.Text);

        if (result)
        {       
            SetAuthCookie(username.Text);
            Session["username"] = username.Text;
            Response.Redirect("Admin/Home.aspx");
        }

        lblalert.Text = "Sorry. Username and Password combination could not be authenticated.";

        failpanel.Visible = true;
    }

    private void SetAuthCookie(string verifiedusername)
    {
        FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, verifiedusername, DateTime.Now, DateTime.Now.AddMinutes(30), false, "your custom data");
        string cookiestr = FormsAuthentication.Encrypt(ticket);
        HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, cookiestr);
        cookie.Path = FormsAuthentication.FormsCookiePath;
        Response.Cookies.Add(cookie);
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        UserManager manager = new UserManager();
        lblalert.Text = "Password hint: " + manager.GetPasswordHint();
        failpanel.Visible = true;

    }

}
