﻿/*
    _                    _ _ _____             _           
   / \   _ __ ___  _ __ | (_)  ___|__  ___  __| | ___ _ __ 
  / _ \ | '_ ` _ \| '_ \| | | |_ / _ \/ _ \/ _` |/ _ \ '__|
 / ___ \| | | | | | |_) | | |  _|  __/  __/ (_| |  __/ |   
/_/   \_\_| |_| |_| .__/|_|_|_|  \___|\___|\__,_|\___|_|   
                  |_|        
 * AmpliFeeder v1.0
 * AmpliFeeder is (C) Jon Paul Davies 2009 jonpauldavies@gmail.com
 * http://www.twitter.com/jonpauldavies
 * 
 * AmpliFeeder is available under the GNU Affero General Public License 
 * (or AGPL for short),a version of the GNU GPL designed specifically 
 * for web applications. All trademarks, slogans, text or logo represented, 
 * used or infered to in this application are the property of their respective owners. 
 * 
 * AGPL: http://www.fsf.org/licensing/licenses/agpl-3.0.html
*/

using System;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;
using JDEE.AMPLIFEEDER.BLL.Channels;

public partial class Detail : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            var uis = new UIService();

            if (Application["ThemeName"] == null)
            {
                Application["ThemeName"] = uis.GetCurrentThemeName();
            }

            ClientScript.RegisterStartupScript(GetType(), "message", string.Format("var ThemeName = '{0}'", Application["ThemeName"]), true);

            RenderRssLinks();
        }
    }

    public void RenderRssLinks()
    {
        ChannelManager chanman = new ChannelManager();

        List<IChannel> channels = chanman.GetActiveChannels();

        foreach (IChannel channel in channels)
        {
            RenderRssLink(channel);
        }
    }

    private void RenderRssLink(IChannel channel)
    {
        HtmlLink cssRef = new HtmlLink();
        cssRef.Href = channel.FeedUri.ToString();
        cssRef.Attributes["rel"] = "alternate";
        cssRef.Attributes["type"] = "application/rss+xml";
        cssRef.Attributes["title"] = channel.Title + " RSS Feed";
        Page.Header.Controls.Add(cssRef);
    }
}
